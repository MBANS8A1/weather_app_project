Sean's programming tasks

-button
-buttonCourts
-courtsFrames

Nikita's programming tasks
-resultsFrame
-courtDetails
-buttonsWeather

Gleb's programming tasks
-
-style folder with .less files
-buttonResults
-iPhone
-nodejs and react installation files

Eligijus's programming tasks
-review code put in by previous three members above and add, delete, and change code; check rendering works.